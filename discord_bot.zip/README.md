# 🤖 Bot Discord Avançado - Agendador de Mensagens

Um bot Discord completo e avançado para agendamento automático de mensagens, anúncios e embeds em horários definidos.

## ✨ Funcionalidades

### 📅 Agendamento de Mensagens
- **Mensagens de texto** - Agende mensagens simples para qualquer canal
- **Mensagens com Embed** - Crie embeds interativos com título, descrição, cor, imagem e rodapé
- **Anúncios com @everyone** - Envie anúncios importantes para toda a comunidade
- **Recorrência** - Configure mensagens diárias, semanais ou com intervalo personalizado
- **Edição e remoção** - Gerencie mensagens agendadas facilmente

### 📢 Sistema de Anúncios
- **Anúncio rápido** - Envie anúncios instantâneos
- **Anúncio com embed** - Crie anúncios profissionais com wizard interativo
- **Templates** - Use templates pré-definidos (boas-vindas, eventos, atualizações, sorteios)

### ⚙️ Gerenciamento
- **Configurações por servidor** - Fuso horário, limite de mensagens, canal de logs
- **Estatísticas** - Acompanhe mensagens ativas, inativas e enviadas
- **Limpeza automática** - Remova mensagens antigas automaticamente

## 🚀 Instalação

### 1. Clone ou baixe o projeto
```bash
git clone <url-do-projeto>
cd discord_bot
```

### 2. Instale as dependências
```bash
pip install -r requirements.txt
```

### 3. Configure o token
Edite o arquivo `.env` e substitua `SEU_TOKEN_AQUI` pelo token do seu bot Discord.

> 💡 **Como obter o token:**
> 1. Acesse [Discord Developer Portal](https://discord.com/developers/applications)
> 2. Crie uma nova aplicação
> 3. Vá em "Bot" e clique em "Add Bot"
> 4. Copie o token e cole no `.env`

### 4. Configure as permissões do bot
No Developer Portal, em OAuth2 > URL Generator:
- Scopes: `bot`, `applications.commands`
- Bot Permissions: `Administrator` (recomendado) ou mínimo:
  - Send Messages
  - Read Message History
  - View Channels
  - Manage Messages
  - Mention Everyone

### 5. Execute o bot
```bash
python main.py
```

## 📖 Comandos

### Agendamento
| Comando | Descrição | Permissão |
|---------|-----------|-----------|
| `!agendar` | Menu principal de agendamento | Gerenciar Mensagens |
| `!agendar texto #canal DD/MM/YYYY HH:MM mensagem` | Agenda mensagem de texto | Gerenciar Mensagens |
| `!agendar embed #canal DD/MM/YYYY HH:MM` | Agenda embed interativo | Gerenciar Mensagens |
| `!agendar anuncio #canal DD/MM/YYYY HH:MM mensagem` | Agenda anúncio com @everyone | Administrador |
| `!agendar lista` | Lista mensagens agendadas | Gerenciar Mensagens |
| `!agendar info <id>` | Detalhes de uma mensagem | Gerenciar Mensagens |
| `!agendar editar <id>` | Edita uma mensagem | Gerenciar Mensagens |
| `!agendar remover <id>` | Remove uma mensagem | Gerenciar Mensagens |

### Anúncios
| Comando | Descrição | Permissão |
|---------|-----------|-----------|
| `!anuncio rapido #canal mensagem` | Anúncio instantâneo | Administrador |
| `!anuncio embed #canal` | Anúncio com embed | Administrador |
| `!anuncio template #canal nome vars` | Usa template | Administrador |
| `!anuncio templates` | Lista templates | Administrador |

### Gerenciamento
| Comando | Descrição | Permissão |
|---------|-----------|-----------|
| `!config` | Configurações do servidor | Administrador |
| `!config log #canal` | Define canal de logs | Administrador |
| `!config limite <número>` | Limite de mensagens | Administrador |
| `!config everyone <on/off>` | Permite @everyone | Administrador |
| `!stats` | Estatísticas | Gerenciar Mensagens |
| `!limpar <dias>` | Limpa mensagens antigas | Administrador |

### Utilitários
| Comando | Descrição |
|---------|-----------|
| `!ping` | Verifica latência |
| `!ajuda` | Ajuda geral |
| `!ajuda <comando>` | Ajuda específica |
| `!horario` | Hora atual do bot |

## 📋 Exemplos

### Agendar mensagem de texto
```
!agendar texto #geral 25/12/2026 09:00 Feliz Natal a todos! 🎄
```

### Agendar embed
```
!agendar embed #avisos 01/01/2026 00:00
```
O bot irá fazer perguntas interativas para criar o embed.

### Agendar anúncio
```
!agendar anuncio #anuncios 20/12/2026 18:00 Evento especial hoje às 20h!
```

### Usar template
```
!anuncio template #geral evento nome=Campeonato;data=25/12;hora=20:00;local=#eventos;descricao=Participe!
```

## 🔄 Recorrência

Ao agendar uma mensagem, o bot perguntará sobre recorrência:
- **Única** - Envia uma vez e remove
- **Diária** - Envia todos os dias no mesmo horário
- **Semanal** - Envia toda semana
- **Personalizada** - Define intervalo em dias

## 🗄️ Banco de Dados

O bot usa SQLite para armazenar:
- Mensagens agendadas
- Logs de envio
- Configurações por servidor

Arquivo: `data/scheduled_messages.db`

## 📁 Estrutura do Projeto

```
discord_bot/
├── main.py                    # Arquivo principal
├── .env                       # Configurações (não compartilhe!)
├── requirements.txt           # Dependências
├── README.md                  # Este arquivo
├── data/                      # Banco de dados e logs
│   ├── scheduled_messages.db
│   └── bot.log
├── utils/                     # Utilitários
│   ├── config.py              # Configurações
│   ├── database.py            # Banco de dados
│   ├── scheduler.py           # Sistema de agendamento
│   └── helpers.py             # Funções auxiliares
└── cogs/                      # Módulos de comandos
    ├── scheduled_messages.py  # Agendamento principal
    ├── announcements.py       # Anúncios avançados
    ├── management.py          # Gerenciamento
    ├── utilities.py           # Utilitários
    └── events.py              # Eventos
```

## 🛡️ Permissões Recomendadas

Para funcionamento completo, o bot precisa de:
- ✅ Ler mensagens
- ✅ Enviar mensagens
- ✅ Enviar embeds
- ✅ Mencionar @everyone
- ✅ Ler histórico de mensagens
- ✅ Gerenciar mensagens

## 📝 Licença

Este projeto é open-source. Sinta-se livre para usar e modificar!

## 💬 Suporte

Em caso de dúvidas ou problemas, verifique:
1. Se o token está correto no `.env`
2. Se as permissões do bot estão configuradas
3. Os logs em `data/bot.log`
