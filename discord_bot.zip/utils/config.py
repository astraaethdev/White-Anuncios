"""
⚙️ Configurações do Bot
"""

import os
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()

class Config:
    """Configurações centralizadas do bot"""

    # 🔑 Token do Bot (OBRIGATÓRIO)
    TOKEN = os.getenv("DISCORD_TOKEN", "SEU_TOKEN_AQUI")

    # 📝 Prefixo dos comandos
    PREFIX = os.getenv("BOT_PREFIX", "!")

    # 👑 IDs dos donos do bot (lista separada por vírgula)
    OWNER_IDS = [int(x.strip()) for x in os.getenv("OWNER_IDS", "").split(",") if x.strip()]

    # 🎨 Cores embed
    COLOR_PRIMARY = 0x5865F2      # Roxo Discord
    COLOR_SUCCESS = 0x57F287      # Verde
    COLOR_WARNING = 0xFEE75C      # Amarelo
    COLOR_ERROR = 0xED4245        # Vermelho
    COLOR_INFO = 0xEB459E         # Rosa

    # ⏰ Configurações de agendamento
    MAX_SCHEDULED_MESSAGES = 100  # Máximo de mensagens agendadas por servidor
    DEFAULT_TIMEZONE = "America/Sao_Paulo"

    # 📊 Banco de dados
    DB_PATH = "data/scheduled_messages.db"

    # 🌐 Links úteis (opcional)
    SUPPORT_SERVER = os.getenv("SUPPORT_SERVER", "")
    BOT_INVITE = os.getenv("BOT_INVITE", "")
